BASE_URL = "https://rest.coinapi.io/"

API_KEY = "E9AA1513-E247-45ED-8D64-2847183E1ADC"

# OR 

# API_KEY = "B587E217-B6DD-4216-93C0-2D022E405F34" # because we have 100 limites/day